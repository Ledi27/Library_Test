﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Test.Data
{
    public class MySqlDataService :IService
    {
        public void Example()
        {
            throw new NotImplementedException();
        }

        public string Get(int id)
        {
            throw new NotImplementedException();
        }

        public string GetAll()
        {
            throw new NotImplementedException();
        }

        public void NewMethod()
        {
            throw new NotImplementedException();
        }
    }
}
    

