﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Test
{
     public class Chapter:EntityBase
    {
        public string Title  { get; set; }
        public int NumberOfpage { get; set; }
    }
}
