﻿namespace Library.API.Dto
{
    public class PutLibraryDto
    {
        public string Title { get; set; }
    }
}
